﻿using Microsoft.EntityFrameworkCore;

namespace DailyApp.API.DataModel
{
    /// <summary>
    /// 数据库上下文
    /// </summary>
    public class DailyDbContext:DbContext
    {
        public DailyDbContext(DbContextOptions<DailyDbContext>options):base(options)
        {
            
        }

        public DbSet<AccountInfo> AccountInfo { get; set; } 
    }
}
