﻿namespace DailyApp.API.DTOs
{
    /// <summary>
    /// DTO  数据传输对象（data transfer object)
    /// </summary>
    /// 账号DTO（接收注册信息）
    public class AccountInfoDTO
    {
        public string Name { get; set; }
        public string Account { get; set; }
        public string Password { get; set; }
    }
}
