﻿namespace DailyApp.API.APIResponses
{
    public class APIResponse
    {
        public int ResultCode { get; set; }
        public string Msg { get; set; }
        public object ResultData { get; set; }
    }
}
