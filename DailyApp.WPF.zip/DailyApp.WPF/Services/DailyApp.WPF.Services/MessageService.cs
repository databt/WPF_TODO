﻿using DailyApp.WPF.Services.Interfaces;

namespace DailyApp.WPF.Services
{
    public class MessageService : IMessageService
    {
        public string GetMessage()
        {
            return "Hello from the Message Service";
        }
    }
}
