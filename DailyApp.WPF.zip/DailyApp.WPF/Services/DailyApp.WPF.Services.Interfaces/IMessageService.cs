﻿namespace DailyApp.WPF.Services.Interfaces
{
    public interface IMessageService
    {
        string GetMessage();
    }
}
