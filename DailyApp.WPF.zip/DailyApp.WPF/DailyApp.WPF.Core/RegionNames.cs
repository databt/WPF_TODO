﻿namespace DailyApp.WPF.Core
{
    public static class RegionNames
    {
        public const string ContentRegion = "ContentRegion";
    }
}
